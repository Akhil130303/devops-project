# Deployment of Super Mario on Kubernetes using Terraform

## 𝐒𝐮𝐩𝐞𝐫 𝐦𝐚𝐫𝐢𝐨 𝐭𝐡𝐞 𝐠𝐚𝐦𝐞 𝐰𝐡𝐢𝐜𝐡 𝐰𝐞 𝐰𝐢𝐥𝐥 𝐧𝐞𝐯𝐞𝐫 𝐟𝐨𝐫𝐠𝐞𝐭 𝐬𝐨 𝐭𝐨𝐝𝐚𝐲 𝐰𝐞 𝐚𝐫𝐞 𝐠𝐨𝐢𝐧𝐠 𝐭𝐨 𝐝𝐞𝐩𝐥𝐨𝐲𝐞𝐝 𝐢𝐭 𝐨𝐧 𝐄𝐊𝐒 𝐮𝐬𝐢𝐧𝐠 𝐓𝐞𝐫𝐫𝐚𝐟𝐨𝐫𝐦 𝐯𝐢𝐚 𝐀𝐖𝐒 𝐄𝐂𝟐

![supermario](https://imgur.com/rC4Qe8g.png)

## Detailed Project Blob Link : https://harshhaa.hashnode.dev/deployment-of-super-mario-on-kubernetes-using-terraform

## Project Source Code : https://github.com/NotHarshhaa/Deployment-of-super-Mario-on-Kubernetes-using-terraform

# Thank you

Thank you for taking the time to work on this tutorial/labs. Let me know what you thought!

#### Author by [Harshhaa Reddy](https://github.com/NotHarshhaa)

### Ensure to follow me on GitHub. Please star/share this repository!
