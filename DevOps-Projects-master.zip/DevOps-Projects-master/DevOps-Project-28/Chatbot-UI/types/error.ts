export interface ErrorMessage {
  code: String | null;
  title: String;
  messageLines: String[];
}
