package com.stalin.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.*;

@SpringBootTest
class DemoWorkshopApplicationTests {

	@Test
	void contextLoads() {
		List li = new ArrayList<String> ();
	}

}
